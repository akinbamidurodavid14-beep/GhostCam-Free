package com.ghostcam.free

import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView

    private val pickMedia = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) playMedia(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 9, 15)
        window.navigationBarColor = android.graphics.Color.rgb(9, 9, 15)
        buildInterface()
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 18)
            setBackgroundColor(android.graphics.Color.rgb(9, 9, 15))
        }

        val brand = TextView(this).apply {
            text = "GHOSTCAM"
            textSize = 27f
            setTextColor(android.graphics.Color.WHITE)
            letterSpacing = 0.12f
            gravity = Gravity.CENTER
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, 55))

        val subtitle = TextView(this).apply {
            text = "FREE MEDIA CAMERA STUDIO"
            textSize = 11f
            gravity = Gravity.CENTER
            letterSpacing = 0.18f
            setTextColor(0xFFB7A6F7.toInt())
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, 30))

        playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setBackgroundColor(0xFF171522.toInt())
        }
        val playerParams = LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = 20
            bottomMargin = 18
        }
        root.addView(playerView, playerParams)

        status = TextView(this).apply {
            text = "No media selected"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFFD7D3E4.toInt())
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 38))

        val choose = Button(this).apply {
            text = "CHOOSE PHOTO OR VIDEO"
            setOnClickListener { pickMedia.launch("*/*") }
        }
        root.addView(choose, LinearLayout.LayoutParams(-1, 54))

        val loop = Button(this).apply {
            text = "LOOP PLAYBACK: ON"
            setOnClickListener {
                val p = player
                if (p == null) {
                    Toast.makeText(this@MainActivity, "Choose a video first", Toast.LENGTH_SHORT).show()
                } else {
                    val enabled = p.repeatMode != Player.REPEAT_MODE_ONE
                    p.repeatMode = if (enabled) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                    text = if (enabled) "LOOP PLAYBACK: ON" else "LOOP PLAYBACK: OFF"
                }
            }
        }
        root.addView(loop, LinearLayout.LayoutParams(-1, 50))

        val note = TextView(this).apply {
            text = "Preview only • Does not replace the camera inside other apps"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0xFF898397.toInt())
            setPadding(4, 14, 4, 0)
        }
        root.addView(note, LinearLayout.LayoutParams(-1, 42))

        setContentView(root)
    }

    private fun playMedia(uri: Uri) {
        releasePlayer()
        val newPlayer = ExoPlayer.Builder(this).build()
        player = newPlayer
        playerView.player = newPlayer
        newPlayer.setMediaItem(MediaItem.fromUri(uri))
        newPlayer.repeatMode = Player.REPEAT_MODE_ONE
        newPlayer.prepare()
        newPlayer.playWhenReady = true
        status.text = "Playing selected media • Loop enabled"
        newPlayer.addListener(object : Player.Listener {
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                status.text = "This file could not be played. Try another video."
            }
        })
    }

    private fun releasePlayer() {
        playerView.player = null
        player?.release()
        player = null
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        releasePlayer()
        super.onDestroy()
    }
}
