# GhostCam Free (Android starter project)

A free Android Studio project for selecting local media and previewing video with looping playback.

## What it currently does
- Opens Android's system media picker.
- Plays selected videos in an in-app preview.
- Repeats video playback by default.
- Includes a loop on/off control.
- Uses a dark purple/black interface.

## Important limitation
This is a media preview app, not a system virtual-camera driver. On a normal, non-rooted Android phone, an ordinary third-party app cannot simply replace the camera feed inside WhatsApp, Instagram, or every other app. This project does not claim to do that.

## Build an APK
1. Install Android Studio on a computer.
2. Open the `GhostCamFree` folder.
3. Allow Gradle sync to finish (internet is needed the first time to download Android dependencies).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

Minimum Android version: Android 8.0 (API 26).
