# Build an installable APK

This project folder contains an automated GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. Upload the contents of this folder to a new GitHub repository (branch `main`).
2. Open the repository's **Actions** tab.
3. Select **Build GhostCam Free APK** and press **Run workflow** (or wait for the first push build).
4. When the run finishes successfully, open the run and download the `GhostCamFree-debug-apk` artifact.
5. Extract the artifact on your phone and tap `app-debug.apk` to install. If Android asks, allow your browser or file manager to install unknown apps for this one installation.

The debug APK is unsigned for Play Store release but can be installed manually. The app is a local media preview player; it does not replace camera input in WhatsApp, Instagram, or other apps.
